
export const products = [
  { id: 1, name: "Diana Winter Jacket", price: 1299, image: "https://source.unsplash.com/400x400/?jacket,winter" },
  { id: 2, name: "Diana Down Coat", price: 1599, image: "https://source.unsplash.com/400x400/?coat,winter" },
  { id: 3, name: "Diana Puffer Vest", price: 899, image: "https://source.unsplash.com/400x400/?vest,winter" }
];
